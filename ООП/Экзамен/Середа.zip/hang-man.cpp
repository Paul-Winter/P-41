﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <chrono>
#include <windows.h>

using namespace std;
using namespace chrono;

// Настройка консоли для кириллицы
void setupConsole()
{
    SetConsoleOutputCP(1251);
    SetConsoleCP(1251);
    setlocale(LC_ALL, "Russian");
}

// Шифрование
string xorCipher(const string& input, char key = 'X')
{
    string result = input;
    for (char& c : result) c ^= key;
    return result;
}

// Создание файла со словами
void createWordFile()
{
    vector<string> words =
    {
        "ПРОГРАММИРОВАНИЕ", "КОМПЬЮТЕР", "АЛГОРИТМ", "РАЗРАБОТКА",
        "ВИСЕЛИЦА", "ИНТЕРНЕТ", "ТЕЛЕФОН", "УНИВЕРСИТЕТ",
        "СТУДЕНТ", "ПРЕПОДАВАТЕЛЬ", "КОДИРОВАНИЕ", "ДЕШИФРАТОР",
        "КРИПТОГРАФИЯ", "АРХИТЕКТУРА", "КОНТРОЛЛЕР"
    };

    ofstream file("words.dat", ios::binary);
    for (const auto& word : words) {
        string encrypted = xorCipher(word);
        size_t len = encrypted.length();
        file.write((char*)&len, sizeof(len));
        file.write(encrypted.c_str(), len);
    }
}

// Загрузка слов из файла
vector<string> loadWords()
{
    vector<string> words;
    ifstream file("words.dat", ios::binary);

    if (!file.is_open())
    {
        cout << "Создаю файл со словами...\n";
        createWordFile();
        file.open("words.dat", ios::binary);
    }

    while (file.peek() != EOF)
    {
        size_t len;
        file.read((char*)&len, sizeof(len));

        string encrypted(len, ' ');
        file.read(&encrypted[0], len);
        words.push_back(xorCipher(encrypted));
    }
    return words;
}

// Рисование виселицы (интегрированные картинки)
void drawHangman(int lost)
{
    system("cls");

    if (lost == 0)
    {
        cout << "__________" << endl;
    }
    else if (lost == 1)
    {
        cout << "     |" << endl;
        cout << "     |" << endl;
        cout << "     |" << endl;
        cout << "     |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 2)
    {
        cout << "  ---|-" << endl;
        cout << "     |" << endl;
        cout << "     |" << endl;
        cout << "     |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 3)
    {
        cout << "  |--|-" << endl;
        cout << "  O  |" << endl;
        cout << "     |" << endl;
        cout << "     |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 4)
    {
        cout << "  |--|-" << endl;
        cout << "  0  |" << endl;
        cout << "     |" << endl;
        cout << "     |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 5)
    {
        cout << "  |--|-" << endl;
        cout << "  0  |" << endl;
        cout << "  |  |" << endl;
        cout << "     |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 6)
    {
        cout << "  |--|-" << endl;
        cout << "  0  |" << endl;
        cout << " /|  |" << endl;
        cout << "     |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 7)
    {
        cout << "  |--|-" << endl;
        cout << "  0  |" << endl;
        cout << " /|\\ |" << endl;
        cout << "     |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 8)
    {
        cout << "  |--|-" << endl;
        cout << "  0  |" << endl;
        cout << " /|\\ |" << endl;
        cout << " /   |" << endl;
        cout << "_____|_____" << endl;
    }
    else if (lost == 9)
    {
        cout << "  |--|-" << endl;
        cout << "  0  |" << endl;
        cout << " /|\\ |" << endl;
        cout << " / \\ |" << endl;
        cout << "_____|_____" << endl;
    }
}

// Показ слова
void showWord(const string& word, const vector<bool>& guessed)
{
    cout << "\n\nСлово: ";
    for (size_t i = 0; i < word.size(); i++) {
        cout << (guessed[i] ? word[i] : '_') << ' ';
    }
    cout << endl;
}

// Форматирование времени
string timeStr(seconds dur)
{
    int m = dur.count() / 60, s = dur.count() % 60;
    return (m < 10 ? "0" : "") + to_string(m) + ":" + (s < 10 ? "0" : "") + to_string(s);
}

int main()
{
    setupConsole();
    srand(time(0));

    vector<string> words = loadWords();
    if (words.empty()) return 1;

    char again;
    cout << string(50, '=') << "\n      ДОБРО ПОЖАЛОВАТЬ В ИГРУ ВИСЕЛИЦА!\n" << string(50, '=') << endl;

    do {
        string secret = words[rand() % words.size()];
        vector<bool> guessed(secret.size(), false);
        vector<char> used;
        int errors = 0;
        bool won = false;

        auto start = steady_clock::now();

        drawHangman(0);
        showWord(secret, guessed);
        cout << "\nУ вас всего 9 попыток!\n";

        while (errors < 9 && !won)
        {
            cout << "\nИспользованные буквы: ";
            for (char c : used) cout << c << ' ';
            cout << "\nОсталось попыток: " << 9 - errors << "\nВведите букву: ";

            string input;
            cin >> input;
            if (input.empty()) continue;

            char letter = toupper(input[0]);

            // Проверка на русскую букву
            if (!(letter >= 'А' && letter <= 'Я'))
            {
                cout << "Нужна русская буква!\n";
                continue;
            }

            if (find(used.begin(), used.end(), letter) != used.end())
            {
                cout << "Такая буква уже была!\n";
                continue;
            }

            used.push_back(letter);

            bool found = false;
            for (size_t i = 0; i < secret.size(); i++)
            {
                if (secret[i] == letter)
                {
                    guessed[i] = true;
                    found = true;
                }
            }

            if (found)
            {
                cout << "Есть такая буква! :)\n";
            }
            else
            {
                errors++;
                cout << "Нет такой буквы! :(\n";
            }

            won = true;
            for (bool g : guessed) if (!g) { won = false; break; }

            drawHangman(errors);
            showWord(secret, guessed);
        }

        if (won)
        {
            cout << "\nПОБЕДА! Слово: " << secret << endl;
        }
        else
        {
            drawHangman(9); // Показываем финальную стадию (полная виселица)
            showWord(secret, guessed);
            cout << "\nПОРАЖЕНИЕ! Слово: " << secret << endl;
        }

        auto end = steady_clock::now();
        auto duration = duration_cast<seconds>(end - start);

        // Статистика
        cout << "\n" << string(50, '=') << "\n           СТАТИСТИКА\n" << string(50, '=');
        cout << "\nВремя: " << timeStr(duration);
        cout << "\nПопытки: " << errors << "/9";
        cout << "\nСлово: " << secret;
        cout << "\nИспользованные буквы: ";
        for (char c : used) cout << c << ' ';
        cout << "\nРезультат: " << (won ? "ПОБЕДА" : "ПОРАЖЕНИЕ") << endl;
        cout << string(50, '=') << "\n\nЕщё раз? (y/n): ";

        cin >> again;
    } while (again == 'y' || again == 'Y');

    cout << "До свидания!\n";
    return 0;
}